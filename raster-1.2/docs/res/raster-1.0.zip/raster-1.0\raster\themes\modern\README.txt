
About this theme:
-----------------
Files in this directory where created from the Photoshop and scripts
files in the /photoshop directory. Use the Photoshop files and scripts
to design themes of your own.

1. Copy tile*.jsx files to the Photoshop scripts folder, for example:
   "C:\Program Files\Adobe\Adobe Photoshop CS4 (64 Bit)\Presets\Scripts"

2. Change colors in the photoshop files, keeping in mind to preserve the
   layers current dimmensions.

3. Run the tile scripts to generate the CSS sprites. Save the new
   sprites to your own theme folder.