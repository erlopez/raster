Description:

    This directory contains the distributable files for the Raster UI Library.

Usage:

    Copy the /raster directory to your web application root folder so your
    pages can link to the library's scripts, css, and images.