Directory contents:

/demos       Sample programs
/docs        Raster documentation
/photoshop   Raster theme Photoshop files and scripts to create sprite images
/raster      Raster redistributable files. Copy this directory to your web
             application root folder so your pages can link to Raster's
             scripts, css, and images.
